import React, { useState, useCallback } from 'react';
import { Header } from './Layout/Header';
import { Navbar } from './Layout/Navbar';
import { LoginForm } from './Auth/LoginForm';
import { CategoriesSection } from './Categories/CategoriesSection';
import { CompareSection } from './Compare/CompareSection';
import { AnalyticsSection } from './Analytics/AnalyticsSection';
import { SettingsSection } from './Settings/SettingsSection';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

type Tab = 'home' | 'compare' | 'analytics' | 'settings';

export function AppContent() {
  const { user } = useAuth();
  const { theme } = useTheme();
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [searchResults, setSearchResults] = useState<Array<{ name: string; price: string }>>([]);
  const isDark = theme === 'dark';

  const handleSearchResults = useCallback((results: Array<{ name: string; price: string }>) => {
    setSearchResults(results);
  }, []);

  if (!user) {
    return (
      <div className={`min-h-screen flex items-center justify-center p-4 ${
        isDark ? 'bg-gray-900' : 'bg-gray-50'
      }`}>
        <LoginForm />
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-200 ${
      isDark ? 'bg-gray-900' : 'bg-gray-50'
    }`}>
      <Header />
      <main className="pt-24 pb-24">
        {activeTab === 'home' && <CategoriesSection />}
        {activeTab === 'compare' && <CompareSection onSearchResults={handleSearchResults} />}
        {activeTab === 'analytics' && <AnalyticsSection />}
        {activeTab === 'settings' && <SettingsSection />}
      </main>
      <Navbar 
        activeTab={activeTab} 
        onTabChange={setActiveTab}
        searchResults={searchResults}
      />
    </div>
  );
}