import React from 'react';
import { History, ShoppingBag, Wallet, RotateCcw } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { OrderHistory } from './OrderHistory';
import { useAnalytics } from '../../context/AnalyticsContext';

export function AnalyticsSection() {
  const { theme } = useTheme();
  const { totalOrders, totalAmount, orders, resetAnalytics } = useAnalytics();
  const isDark = theme === 'dark';

  return (
    <div className="w-full max-w-3xl mx-auto space-y-4 px-4 pb-20">
      <div className="flex justify-between items-center mb-2">
        <h1 className={`text-xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
          Analytics
        </h1>
        {orders.length > 0 && (
          <button
            onClick={resetAnalytics}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg transition-all duration-200 ${
              isDark 
                ? 'bg-white/10 hover:bg-white/15 text-white' 
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span className="text-sm">Reset</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className={`${
          isDark ? 'bg-white/10' : 'bg-white'
        } backdrop-blur-md rounded-xl p-4 transition-all duration-200 hover:scale-[1.02]`}>
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${
              isDark ? 'bg-white/10' : 'bg-purple-100'
            }`}>
              <ShoppingBag className={`w-5 h-5 ${
                isDark ? 'text-white' : 'text-purple-600'
              }`} />
            </div>
            <div>
              <p className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-500'}`}>
                Total Orders
              </p>
              <p className={`text-xl font-semibold ${
                isDark ? 'text-white' : 'text-gray-900'
              }`}>
                {totalOrders}
              </p>
            </div>
          </div>
        </div>

        <div className={`${
          isDark ? 'bg-white/10' : 'bg-white'
        } backdrop-blur-md rounded-xl p-4 transition-all duration-200 hover:scale-[1.02]`}>
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${
              isDark ? 'bg-white/10' : 'bg-green-100'
            }`}>
              <Wallet className={`w-5 h-5 ${
                isDark ? 'text-white' : 'text-green-600'
              }`} />
            </div>
            <div>
              <p className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-500'}`}>
                Total Spent
              </p>
              <p className={`text-xl font-semibold ${
                isDark ? 'text-white' : 'text-gray-900'
              }`}>
                ₹{totalAmount.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>

      {orders.length > 0 && (
        <div className={`${
          isDark ? 'bg-white/10' : 'bg-white'
        } backdrop-blur-md rounded-xl p-4 transition-all duration-200`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${
                isDark ? 'bg-white/10' : 'bg-blue-100'
              }`}>
                <History className={`w-5 h-5 ${
                  isDark ? 'text-white' : 'text-blue-600'
                }`} />
              </div>
              <h2 className={`text-lg font-semibold ${
                isDark ? 'text-white' : 'text-gray-900'
              }`}>
                Order History
              </h2>
            </div>
            <span className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-500'}`}>
              Last {orders.length} orders
            </span>
          </div>
          <OrderHistory />
        </div>
      )}

      {orders.length === 0 && (
        <div className={`flex flex-col items-center justify-center py-12 ${
          isDark ? 'text-white/60' : 'text-gray-500'
        }`}>
          <History className="w-12 h-12 mb-4 opacity-50" />
          <p className="text-lg font-medium mb-2">No Order History</p>
          <p className="text-sm text-center">
            Your order history will appear here once you make your first order
          </p>
        </div>
      )}
    </div>
  );
}