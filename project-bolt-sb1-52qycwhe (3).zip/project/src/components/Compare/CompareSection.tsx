import React, { useState, useCallback, useEffect } from 'react';
import { SearchBar } from './SearchBar';
import { categories } from '../../data/categories';
import { productCategories } from '../../data/productCategories';
import { useTheme } from '../../context/ThemeContext';
import { Star, Clock, Truck } from 'lucide-react';

interface SearchResult {
  name: string;
  logo: string;
  url: string;
  category: string;
  rating: number;
  price: string;
  deliveryTime?: string;
  minOrder?: string;
}

interface CompareSectionProps {
  onSearchResults: (results: Array<{ name: string; price: string }>) => void;
}

const appDetails: Record<string, { 
  rating: number; 
  price: string;
  deliveryTime?: string;
  minOrder?: string;
}> = {
  'Swiggy': { rating: 4.2, price: '₹₹', deliveryTime: '30-45 min', minOrder: '₹50' },
  'Zomato': { rating: 4.3, price: '₹₹', deliveryTime: '35-50 min', minOrder: '₹100' },
  'FreshMenu': { rating: 4.0, price: '₹₹', deliveryTime: '45-60 min', minOrder: '₹200' },
  'KFC': { rating: 4.1, price: '₹₹₹', deliveryTime: '30-45 min', minOrder: '₹200' },
  'Domino\'s': { rating: 4.2, price: '₹₹', deliveryTime: '30 min', minOrder: '₹150' },
  'McDonald\'s': { rating: 4.0, price: '₹₹', deliveryTime: '25-40 min', minOrder: '₹100' },
  'Zepto': { rating: 4.4, price: '₹', deliveryTime: '10-15 min', minOrder: '₹99' },
  'Blinkit': { rating: 4.3, price: '₹', deliveryTime: '10-20 min', minOrder: '₹99' },
  'BigBasket': { rating: 4.2, price: '₹₹', deliveryTime: '2-3 hours', minOrder: '₹500' },
  'Ola Mart': { rating: 4.0, price: '₹', deliveryTime: '15-25 min', minOrder: '₹99' },
  'MedPlus': { rating: 4.1, price: '₹₹', deliveryTime: '60-90 min', minOrder: '₹200' },
  'Apollo 247': { rating: 4.3, price: '₹₹', deliveryTime: '45-60 min', minOrder: '₹100' },
  'PharmEasy': { rating: 4.2, price: '₹₹', deliveryTime: '60-90 min', minOrder: '₹150' },
  'MakeMyTrip': { rating: 4.1, price: '₹₹₹' },
  'RedBus': { rating: 4.2, price: '₹₹' },
  'Rapido': { rating: 4.0, price: '₹' },
  'Uber': { rating: 4.3, price: '₹₹' },
  'Ola': { rating: 4.2, price: '₹₹' },
  'BookMyShow': { rating: 4.4, price: '₹₹' },
  'PVR': { rating: 4.3, price: '₹₹₹' },
};

export function CompareSection({ onSearchResults }: CompareSectionProps) {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  const [results, setResults] = useState<SearchResult[]>([]);

  const handleSearch = useCallback((query: string) => {
    if (!query) {
      setResults([]);
      return;
    }

    const searchQuery = query.toLowerCase();
    const searchResults: SearchResult[] = [];

    categories.forEach(category => {
      const categoryProducts = productCategories[category.title] || [];
      const matchesProduct = categoryProducts.some(product => 
        product.toLowerCase().includes(searchQuery)
      );

      category.apps.forEach(app => {
        if (app.name.toLowerCase().includes(searchQuery) || matchesProduct) {
          searchResults.push({
            ...app,
            category: category.title,
            ...appDetails[app.name],
          });
        }
      });
    });

    setResults(searchResults);
  }, []);

  // Use useEffect to notify parent of search results changes
  useEffect(() => {
    onSearchResults(
      results.map(result => ({
        name: result.name,
        price: result.price
      }))
    );
  }, [results, onSearchResults]);

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      <div className={`text-center mb-6 ${isDark ? 'text-white' : 'text-gray-900'}`}>
        <h1 className="text-xl font-semibold mb-2">Compare & Find the Best Service</h1>
        <p className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-500'}`}>
          Search for any item or service to compare prices and delivery times across apps
        </p>
      </div>

      <SearchBar onSearch={handleSearch} />

      {results.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {results.map((result, index) => (
            <a
              key={index}
              href={result.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`${
                isDark ? 'bg-white/10' : 'bg-white'
              } backdrop-blur-md rounded-xl p-4 transition-all duration-200 hover:scale-[1.02] group`}
            >
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-white rounded-xl p-2 shadow-lg">
                  <img
                    src={result.logo}
                    alt={result.name}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="flex-1">
                  <h3 className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>
                    {result.name}
                  </h3>
                  <div className="flex items-center space-x-2 mt-1">
                    <div className={`flex items-center space-x-1 ${
                      isDark ? 'text-white/60' : 'text-gray-500'
                    }`}>
                      <Star className="w-4 h-4" />
                      <span className="text-sm">{result.rating}</span>
                    </div>
                    <span className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-500'}`}>
                      • {result.price}
                    </span>
                  </div>
                  {result.deliveryTime && (
                    <div className={`flex items-center space-x-1 mt-1 text-sm ${
                      isDark ? 'text-white/60' : 'text-gray-500'
                    }`}>
                      <Clock className="w-4 h-4" />
                      <span>{result.deliveryTime}</span>
                    </div>
                  )}
                  {result.minOrder && (
                    <div className={`flex items-center space-x-1 mt-1 text-sm ${
                      isDark ? 'text-white/60' : 'text-gray-500'
                    }`}>
                      <Truck className="w-4 h-4" />
                      <span>Min. order {result.minOrder}</span>
                    </div>
                  )}
                </div>
              </div>
            </a>
          ))}
        </div>
      )}

      {results.length === 0 && (
        <div className={`text-center py-12 ${isDark ? 'text-white/60' : 'text-gray-500'}`}>
          <p className="text-lg font-medium">No results found</p>
          <p className="text-sm mt-2">Try searching for different terms</p>
        </div>
      )}
    </div>
  );
}