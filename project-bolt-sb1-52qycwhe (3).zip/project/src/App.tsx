import React from 'react';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { AnalyticsProvider } from './context/AnalyticsContext';
import { AppContent } from './components/AppContent';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AnalyticsProvider>
          <AppContent />
        </AnalyticsProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;